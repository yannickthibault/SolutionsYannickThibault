The zip contains 6 folders indicating the use of the icons.
 
1) Folder 
- this contains an empty folder (for windows) that already bears your logo. This folder is ready for use.

2) ICNS 
-this contains an ico file that you can use to change a folder icon in a Mac.
-Please check this tutorial on how to change your folder Icons in Mac
http://www.visualpharm.com/articles/change_mac_icons.html

3) ICO
- contains an .ico file that you can use to change your folder icon in Windows.
- This Tutorial provides a video explanation of how to change your folder icon in Windows using ico.
http://lifehacker.com/5898507/how-to-customize-any-folder-or-app-icon-in-windows

4) iOS (PNGS) & Win (PNGS)
- contain PNGS saved in popular icon sizes. You can convert these to ico, icns or even use them as an app icon (you need an app developer to do this for you). Or simply use it as a graphic in your website.

5) Web Favicon
- the icon here is optimize as a web favicon. You can provide this to your web developer so your icon will appear in the address bar of your site visitor